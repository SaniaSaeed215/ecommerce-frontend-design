# E-Commerce Frontend Project

This is a static frontend for an e-commerce website built using HTML, CSS, and JavaScript.
##  Technologies

- HTML5  
- CSS3  
- JavaScript  
- Font Awesome (for icons)  
